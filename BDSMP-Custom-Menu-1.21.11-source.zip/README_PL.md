# BDSMP Custom Menu — Minecraft 1.21.11

Niezależny mod klienta Fabric, który zastępuje ekran startowy Minecrafta pełnoekranowym menu BDSMP. Nie wymaga FancyMenu.

## Instalacja

1. Zamknij Minecrafta.
2. Usuń albo wyłącz FancyMenu oraz jego konfigurację, jeśli nie chcesz, by nakładały się na nowe menu.
3. Skopiuj `bdsmp-custom-menu-1.0.0.jar` do folderu `mods` instancji BDSMP.
4. Uruchom Minecraft 1.21.11 na Fabric.

Menu zawiera Singleplayer, Multiplayer, listę zainstalowanych modów, ustawienia i wyjście z gry. Dwa małe przyciski Minecrafta (język i dostępność) znikają wraz z oryginalnym ekranem tytułowym.

## Budowanie

Projekt wymaga JDK 21 i Gradle. Uruchom `gradle build`; gotowy plik pojawi się w `build/libs`.
