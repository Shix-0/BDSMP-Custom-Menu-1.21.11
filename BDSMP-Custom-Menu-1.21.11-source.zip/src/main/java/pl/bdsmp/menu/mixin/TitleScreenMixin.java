package pl.bdsmp.menu.mixin;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.screens.TitleScreen;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import pl.bdsmp.menu.screen.BdsmpTitleScreen;

@Mixin(TitleScreen.class)
public abstract class TitleScreenMixin {
    @Inject(method = "init", at = @At("TAIL"))
    private void bdsmp$replaceVanillaTitleScreen(CallbackInfo callback) {
        Minecraft.getInstance().setScreen(new BdsmpTitleScreen());
    }
}
