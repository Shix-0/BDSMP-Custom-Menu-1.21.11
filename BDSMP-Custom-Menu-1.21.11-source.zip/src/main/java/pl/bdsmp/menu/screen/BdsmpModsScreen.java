package pl.bdsmp.menu.screen;

import net.fabricmc.loader.api.FabricLoader;
import net.fabricmc.loader.api.ModContainer;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

import java.util.List;

public final class BdsmpModsScreen extends Screen {
    private final Screen parent;
    private final List<ModContainer> mods = FabricLoader.getInstance().getAllMods().stream()
            .sorted((a, b) -> a.getMetadata().getName().compareToIgnoreCase(b.getMetadata().getName()))
            .toList();
    private int scroll;

    public BdsmpModsScreen(Screen parent) {
        super(Component.literal("BDSMP Mod Library"));
        this.parent = parent;
    }

    @Override
    protected void init() {
        addRenderableWidget(net.minecraft.client.gui.components.Button.builder(Component.literal("BACK TO BDSMP"),
                button -> this.minecraft.setScreen(this.parent))
                .bounds(24, this.height - 44, 180, 24).build());
    }

    @Override
    public void renderBackground(GuiGraphics graphics, int mouseX, int mouseY, float partialTick) {
        // Draw the same branded artwork as the title screen.
        graphics.blit(net.minecraft.client.renderer.RenderPipelines.GUI_TEXTURED,
                net.minecraft.resources.Identifier.fromNamespaceAndPath("bdsmp_menu", "textures/gui/background.jpg"),
                0, 0, 0, 0, this.width, this.height, 1672, 941);
        graphics.fill(0, 0, this.width, this.height, 0xB808111B);
        graphics.fill(0, 0, this.width, 3, 0xFFFFA64D);
    }

    @Override
    public void render(GuiGraphics graphics, int mouseX, int mouseY, float partialTick) {
        super.renderBackground(graphics, mouseX, mouseY, partialTick);
        graphics.fill(24, 24, this.width - 24, this.height - 62, 0xC80A121C);
        graphics.fill(24, 24, 28, this.height - 62, 0xFFFFA64D);
        graphics.drawString(this.font, "YOUR BDSMP SETUP", 48, 42, 0xFFFFB66D, false);
        graphics.drawString(this.font, "Installed mods", 48, 68, 0xFFFFFFFF, false);
        graphics.drawString(this.font, this.mods.size() + " MODS", this.width - 110, 46, 0xFF9FB5CA, false);
        int top = 98;
        int bottom = this.height - 82;
        int visible = Math.max(1, (bottom - top) / 22);
        int start = Math.min(this.scroll, Math.max(0, this.mods.size() - visible));
        for (int i = 0; i < visible && start + i < this.mods.size(); i++) {
            ModContainer mod = this.mods.get(start + i);
            int y = top + i * 22;
            graphics.fill(48, y - 3, this.width - 48, y + 17, (i & 1) == 0 ? 0x44313E4C : 0x22313E4C);
            graphics.drawString(this.font, mod.getMetadata().getName(), 58, y, 0xFFF4F2EA, false);
            graphics.drawString(this.font, "v" + mod.getMetadata().getVersion().getFriendlyString(),
                    this.width - 180, y, 0xFF9FB5CA, false);
        }
        super.render(graphics, mouseX, mouseY, partialTick);
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
        this.scroll = Math.max(0, Math.min(Math.max(0, this.mods.size() - 1), this.scroll - (int) verticalAmount * 3));
        return true;
    }

    @Override
    public void onClose() {
        this.minecraft.setScreen(this.parent);
    }
}
