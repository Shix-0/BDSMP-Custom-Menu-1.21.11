package pl.bdsmp.menu.screen;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.AbstractWidget;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.Tooltip;
import net.minecraft.client.gui.narration.NarrationElementOutput;
import net.minecraft.client.gui.screens.JoinMultiplayerScreen;
import net.minecraft.client.gui.screens.OptionsScreen;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.gui.screens.worldselection.SelectWorldScreen;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.client.renderer.RenderPipelines;

public final class BdsmpTitleScreen extends Screen {
    private static final ResourceLocation BACKGROUND = ResourceLocation.fromNamespaceAndPath(
            "bdsmp_menu", "textures/gui/background.jpg");
    private static final ResourceLocation WORDMARK = ResourceLocation.fromNamespaceAndPath(
            "bdsmp_menu", "textures/gui/wordmark.png");
    private static final int BG_WIDTH = 1672;
    private static final int BG_HEIGHT = 941;
    private static final int ACCENT = 0xFFFFA64D;

    public BdsmpTitleScreen() {
        super(Component.literal("BDSMP"));
    }

    @Override
    protected void init() {
        int buttonWidth = Math.min(360, Math.max(250, this.width / 3));
        int buttonHeight = Math.max(38, Math.min(54, this.height / 10));
        int gap = Math.max(7, buttonHeight / 5);
        int x = Math.max(26, this.width / 14);
        int y = Math.max(170, this.height * 2 / 5);
        int availableBottom = this.height - 38;
        int totalHeight = buttonHeight * 5 + gap * 4;
        if (y + totalHeight > availableBottom) {
            buttonHeight = Math.max(30, (availableBottom - y - gap * 4) / 5);
            totalHeight = buttonHeight * 5 + gap * 4;
        }
        if (y + totalHeight > availableBottom) y = Math.max(110, availableBottom - totalHeight);

        addMenuButton(x, y, buttonWidth, buttonHeight, "SINGLEPLAYER", "Enter your world",
                () -> Minecraft.getInstance().setScreen(new SelectWorldScreen(this)), true);
        y += buttonHeight + gap;
        addMenuButton(x, y, buttonWidth, buttonHeight, "MULTIPLAYER", "Find your people",
                () -> Minecraft.getInstance().setScreen(new JoinMultiplayerScreen(this)), false);
        y += buttonHeight + gap;
        addMenuButton(x, y, buttonWidth, buttonHeight, "MOD LIBRARY", "Your BDSMP setup",
                () -> Minecraft.getInstance().setScreen(new BdsmpModsScreen(this)), false);
        y += buttonHeight + gap;
        addMenuButton(x, y, buttonWidth, buttonHeight, "SETTINGS", "Tune your experience",
                () -> Minecraft.getInstance().setScreen(new OptionsScreen(this, Minecraft.getInstance().options)), false);
        y += buttonHeight + gap;
        addMenuButton(x, y, buttonWidth, buttonHeight, "EXIT GAME", "See you next time",
                () -> Minecraft.getInstance().stop(), false);
    }

    private void addMenuButton(int x, int y, int width, int height, String title, String sub,
                               Runnable action, boolean featured) {
        MenuButton button = new MenuButton(x, y, width, height, title, sub, featured, action);
        button.setTooltip(Tooltip.create(Component.literal(sub)));
        addRenderableWidget(button);
    }

    @Override
    public void renderBackground(GuiGraphics graphics, int mouseX, int mouseY, float partialTick) {
        // The panorama is replaced by the BDSMP artwork drawn in render().
    }

    @Override
    public void render(GuiGraphics graphics, int mouseX, int mouseY, float partialTick) {
        graphics.blit(RenderPipelines.GUI_TEXTURED, BACKGROUND, 0, 0, 0, 0,
                this.width, this.height, BG_WIDTH, BG_HEIGHT);
        graphics.fill(0, 0, this.width, this.height, 0x28040A12);
        graphics.fillGradient(0, 0, this.width * 3 / 5, this.height, 0xD908111B, 0x76101B28);
        graphics.fill(0, 0, this.width, 3, ACCENT);
        graphics.fill(0, this.height - 3, this.width, this.height, 0xAA101C29);

        drawAtmosphere(graphics);
        drawBrand(graphics);
        drawFeaturePanel(graphics);
        super.render(graphics, mouseX, mouseY, partialTick);
        drawFooter(graphics);
    }

    private void drawBrand(GuiGraphics graphics) {
        int logoWidth = Math.min(410, this.width * 35 / 100);
        int logoHeight = logoWidth / 3;
        int x = Math.max(26, this.width / 14);
        int y = Math.max(18, this.height / 18);
        graphics.blit(RenderPipelines.GUI_TEXTURED, WORDMARK, x - 8, y - 14, 0, 0,
                logoWidth, logoHeight, 1086, 362);
        int baseline = y + logoHeight + 4;
        graphics.fill(x, baseline, x + 38, baseline + 2, ACCENT);
        graphics.drawString(this.font, "YOUR WORLD. YOUR PEOPLE.", x + 49, baseline - 4, 0xFFFFC27E, false);
        graphics.drawString(this.font, "A VANILLA-HEARTED ADVENTURE, BUILT TOGETHER", x, baseline + 18, 0xFFD9E1EA, false);
    }

    private void drawFeaturePanel(GuiGraphics graphics) {
        int panelWidth = Math.min(330, this.width / 4);
        int panelX = this.width - panelWidth - Math.max(30, this.width / 16);
        int panelY = this.height / 3;
        int panelHeight = Math.min(this.height / 2, 260);
        if (panelWidth < 210 || this.width < 760) return;

        graphics.fill(panelX, panelY, panelX + panelWidth, panelY + panelHeight, 0xA80A121C);
        graphics.fill(panelX, panelY, panelX + 2, panelY + panelHeight, ACCENT);
        graphics.renderOutline(panelX, panelY, panelWidth, panelHeight, 0x887B8FA3);
        graphics.drawString(this.font, "THE BDSMP EXPERIENCE", panelX + 20, panelY + 22, 0xFFFFB66D, false);
        graphics.drawString(this.font, "More than a world.", panelX + 20, panelY + 62, 0xFFFFFFFF, false);
        graphics.drawString(this.font, "A place shaped by players.", panelX + 20, panelY + 82, 0xFFD5DEE8, false);
        graphics.fill(panelX + 20, panelY + 116, panelX + panelWidth - 20, panelY + 117, 0x887B8FA3);
        graphics.drawString(this.font, "FABRIC  /  1.21.11", panelX + 20, panelY + 136, 0xFF9FB5CA, false);
        graphics.fill(panelX + 20, panelY + panelHeight - 44, panelX + panelWidth - 20, panelY + panelHeight - 43, 0x887B8FA3);
        graphics.fill(panelX + 20, panelY + panelHeight - 28, panelX + 26, panelY + panelHeight - 22, 0xFF64E3A5);
        graphics.drawString(this.font, "READY FOR YOUR NEXT CHAPTER", panelX + 36, panelY + panelHeight - 30, 0xFFD5DEE8, false);
    }

    private void drawAtmosphere(GuiGraphics graphics) {
        double time = (System.currentTimeMillis() % 120000L) / 120000.0;
        int centerX = this.width * 72 / 100;
        int centerY = this.height * 22 / 100;
        int radiusX = Math.max(74, this.width / 11);
        int radiusY = Math.max(38, this.height / 12);
        for (int i = 0; i < 88; i++) {
            double angle = (Math.PI * 2.0 * i / 88.0) + time * Math.PI * 2.0;
            if (i % 3 == 0) continue;
            int px = centerX + (int) (Math.cos(angle) * radiusX);
            int py = centerY + (int) (Math.sin(angle) * radiusY);
            int size = (i % 8 == 0) ? 3 : 1;
            graphics.fill(px, py, px + size, py + size, (i % 4 == 0) ? 0x99FFC078 : 0x667DC6D9);
        }
        // Fine ember lights add motion without external animation assets.
        for (int i = 0; i < 14; i++) {
            int x = this.width * (57 + (i * 19) % 39) / 100;
            int drift = (int) ((time * 480 + i * 71) % Math.max(1, this.height));
            int y = this.height - drift;
            graphics.fill(x, y, x + 2, y + 2, 0xAAFFAC5B);
        }
    }

    private void drawFooter(GuiGraphics graphics) {
        graphics.drawString(this.font, "BDSMP  •  VANILLA, WITH A LITTLE MORE MAGIC", 22, this.height - 20, 0xFFB6C2CF, false);
        String version = "MINECRAFT JAVA  /  FABRIC 1.21.11";
        graphics.drawString(this.font, version, this.width - this.font.width(version) - 22,
                this.height - 20, 0xFFFFC27E, false);
    }

    private static final class MenuButton extends AbstractWidget {
        private final String title;
        private final String subtitle;
        private final boolean featured;
        private final Runnable action;

        private MenuButton(int x, int y, int width, int height, String title, String subtitle,
                           boolean featured, Runnable action) {
            super(x, y, width, height, Component.literal(title));
            this.title = title;
            this.subtitle = subtitle;
            this.featured = featured;
            this.action = action;
        }

        @Override
        protected void renderWidget(GuiGraphics graphics, int mouseX, int mouseY, float partialTick) {
            int x = getX();
            int y = getY();
            int w = this.width;
            int h = this.height;
            boolean hover = isHovered();
            int base = featured ? 0xE52A1E19 : 0xC90A121C;
            graphics.fill(x, y, x + w, y + h, hover ? 0xF23B2A1D : base);
            graphics.fill(x, y, x + (hover ? 5 : 3), y + h, ACCENT);
            graphics.fill(x + 3, y, x + w, y + 1, 0x887C8B99);
            graphics.fill(x + 3, y + h - 1, x + w, y + h, 0x887C8B99);
            if (hover) graphics.renderOutline(x, y, w, h, 0xFFFFC27E);
            int titleY = y + (h - 9) / 2 - (h >= 46 ? 5 : 0);
            graphics.drawString(Minecraft.getInstance().font, this.title, x + 20, titleY,
                    featured || hover ? 0xFFFFC27E : 0xFFF4F2EA, false);
            if (h >= 46) graphics.drawString(Minecraft.getInstance().font, this.subtitle,
                    x + 20, y + h - 16, 0xFFB9C6D2, false);
            graphics.drawString(Minecraft.getInstance().font, "›", x + w - 24,
                    y + (h - 9) / 2, hover ? 0xFFFFC27E : 0xFF8BA0B2, false);
        }

        @Override
        public void onClick(double mouseX, double mouseY) {
            this.action.run();
        }

        @Override
        protected void updateWidgetNarration(NarrationElementOutput narration) {
            narration.add(net.minecraft.client.gui.narration.NarratedElementType.TITLE, getMessage());
        }
    }
}
